define(['require','shared/toaster','modules/settings_cache','modules/dialog_service','dsds_settings','shared/settings_helper'],function(require) {
  

  /**
   * Singleton object that handles some call settings.
   */
  var Toaster = require('shared/toaster');
  var SettingsCache = require('modules/settings_cache');
  var DialogService = require('modules/dialog_service');
  var DsdsSettings = require('dsds_settings');
  var SettingsHelper = require('shared/settings_helper');

  var CallSettings = function cs_callsettings() {
    var _networkTypeCategory = {
      'gprs': 'gsm',
      'edge': 'gsm',
      'umts': 'gsm',
      'hsdpa': 'gsm',
      'hsupa': 'gsm',
      'hspa': 'gsm',
      'hspa+': 'gsm',
      'lte': 'gsm',
      'gsm': 'gsm',
      'is95a': 'cdma',
      'is95b': 'cdma',
      '1xrtt': 'cdma',
      'evdo0': 'cdma',
      'evdoa': 'cdma',
      'evdob': 'cdma',
      'ehrpd': 'cdma'
    };

    var _clirConstantsMapping = {
      'CLIR_DEFAULT': 0,
      'CLIR_INVOCATION': 1,
      'CLIR_SUPPRESSION': 2
    };

    var _settings = window.navigator.mozSettings;
    var _mobileConnections = window.navigator.mozMobileConnections;
    var _voiceTypes = Array.prototype.map.call(_mobileConnections,
      function() { return null; });

    /** mozMobileConnection instance the panel settings rely on */
    var _mobileConnection = null;
    var _imsHandler = null;
    /**
      * To prevent current panle frequently refresh
      *   while the voice type is changing.
      *
      * @param {String} 'cdma' or 'gsm'
      */
    var _currentType = null;

    /**
     * Init function.
     */
    function cs_init() {
      // Get the mozMobileConnection instace for this ICC card.
      _mobileConnection = _mobileConnections[
        DsdsSettings.getIccCardIndexForCallSettings()
      ];
      if (!_mobileConnection) {
        return;
      }

      // Init call setting stuff.
      cs_initVoicePrivacyMode();

      // Update items in the call settings panel.
      window.addEventListener('panelready', function(e) {
        // Get the mozMobileConnection instace for this ICC card.
        _mobileConnection = _mobileConnections[
          DsdsSettings.getIccCardIndexForCallSettings()
        ];
        if (!_mobileConnection) {
          return;
        }

        switch (e.detail.current) {
          case '#call':
            // No need to refresh the call settings items if navigated from
            // panels not manipulating call settings.
            if (e.detail.previous === '#call-cfSettings' ||
                e.detail.previous === '#call-cbSettings') {
              return;
            }

            cs_checkNetworkType();
            break;
        }
      });

      // We need to refresh call setting items as they can be changed in dialer.
      document.addEventListener('visibilitychange', function() {
        if (document.hidden) {
          return;
        }

        switch (Settings.currentPanel) {
          case '#call':
            cs_checkNetworkType();
            break;
        }
      });
    }

    function showToast(msgId) {
      var toast = {
        messageL10nId: msgId,
        latency: 3000,
        useTransition: true
      };
      Toaster.showToast(toast);
    }

    function cs_checkNetworkType() {
      var voice = _mobileConnection.voice;
      var data = _mobileConnection.data;
      _imsHandler = _mobileConnection.imsHandler;
      if (_imsHandler &&
        (_imsHandler.capability === 'voice-over-wifi' ||
        _imsHandler.capability === 'video-over-wifi')) {
        _currentType = _imsHandler.capability;
        cs_updateNetworkTypeLimitedItemsVisibility(_currentType);
      } else if (voice && voice.state === 'registered' &&
        voice.connected === true) {
        _currentType = _networkTypeCategory[voice.type];
        cs_updateNetworkTypeLimitedItemsVisibility(_currentType);
      } else if (data && data.state === 'registered' &&
        data.connected === true) {
        _currentType = _networkTypeCategory[data.type];
        cs_updateNetworkTypeLimitedItemsVisibility(_currentType);
      } else {
        console.log('can not registered');
        cs_updateNetworkTypeLimitedItemsVisibility(null);
      }
    }

    function cs_addNetworkTypeCheckListener() {
      if (_mobileConnection.voice) {
        _mobileConnection.addEventListener('voicechange', cs_onTypeChange);
      }
      if (_mobileConnection.data) {
        _mobileConnection.addEventListener('datachange', cs_onTypeChange);
      }
      if (_imsHandler) {
        _imsHandler.addEventListener('capabilitychange',
          cs_onCapabilityChange);
      }
    }

    function cs_onTypeChange(evt) {
      var voiceType = _mobileConnection.voice && _mobileConnection.voice.type;
      var dataType = _mobileConnection.data && _mobileConnection.data.type;
      if (!voiceType && !dataType) {
        return;
      }
      var newType = _networkTypeCategory[voiceType || dataType];
      if (newType === _currentType) {
        return;
      } else {
        _currentType = newType;
      }
      cs_updateNetworkTypeLimitedItemsVisibility(newType);
    }

    function cs_onCapabilityChange() {
      if (_imsHandler.capability === 'voice-over-wifi' ||
        _imsHandler.capability === 'video-over-wifi') {
        if (_imsHandler.capability === _currentType) {
          return;
        } else {
          _currentType = newType;
        }
        cs_updateNetworkTypeLimitedItemsVisibility(_imsHandler.capability);
      }
    }

    /**
     * Update the network type limited items' visibility based on the
     * voice type or data type.
     */
    function cs_updateNetworkTypeLimitedItemsVisibility(newType) {
      // The following features are limited to GSM types.
      var callForwardingItem =
        document.getElementById('menuItem-callForwarding');
      var callBarringItem =
        document.getElementById('menuItem-callBarring');

      var callWaitingItem = document.getElementById('menuItem-callWaiting');
      var callerIdItem = document.getElementById('menuItem-callerId');
      // The following feature is limited to CDMA types.
      var voicePrivacyItem =
        document.getElementById('menuItem-voicePrivacyMode');
      let fdnMenuItem = document.getElementById('menuItem-callFdn');
      let hrefItem = callForwardingItem.querySelector('a');

      if (!newType) {
        voicePrivacyItem.hidden =
        callWaitingItem.hidden =
        callerIdItem.hidden =
        callForwardingItem.hidden =
        callBarringItem.hidden =
        fdnMenuItem.hidden =
        dtmfItem.hidden = true;
        return;
      }

      let enabled = (newType !== 'gsm' &&
        newType !== 'voice-over-wifi' && newType !== 'video-over-wifi');

      voicePrivacyItem.hidden =
        (newType !== 'cdma');

      let iccObj = getIccByIndex();
      let p1 = getSetting('callforward.settings.ui');
      let p2 = iccObj.getServiceState('fdn');
      Promise.all([p1, p2]).then((values) => {
        let isCFShow = values[0];
        let hasFdn = values[1];
        let cfHidden = enabled;
        if (isCFShow === HIDE) {
          cfHidden = true;
          cs_updateMenuItems(enabled, cfHidden, hasFdn, newType);
        } else if (isCFShow === GRAYOUT) {
          callForwardingItem.classList.add('none-select');
          callForwardingItem.setAttribute('aria-disabled', 'true');
          hrefItem.removeAttribute('href');
          cs_updateMenuItems(enabled, cfHidden, hasFdn, newType);
        } else {
          if (hasFdn) {
            cs_updateFdnStatus().then(() => {
              cs_updateMenuItems(enabled, cfHidden, hasFdn, newType);
            });
          } else {
            callForwardingItem.classList.remove('none-select');
            callForwardingItem.removeAttribute('aria-disabled');
            if (DeviceFeature.getValue('vilte') === 'true') {
              hrefItem.setAttribute('href', '#call-cfsettings-list');
            } else {
              hrefItem.setAttribute('href', '#call-cfSettings');
            }
            cs_updateMenuItems(enabled, cfHidden, hasFdn, newType);
          }
        }
      });
    }

    function cs_updateMenuItems(enabled, cfHidden, hasFdn, newType) {
      let callWaitingItem = document.getElementById('menuItem-callWaiting');
      let callerIdItem = document.getElementById('menuItem-callerId');
      let callForwardingItem =
        document.getElementById('menuItem-callForwarding');
      let callBarringItem =
        document.getElementById('menuItem-callBarring');
      let fdnMenuItem = document.getElementById('menuItem-callFdn');
      let dtmfItem = document.getElementById('menuItem-dtmf');

      callWaitingItem.hidden = enabled;
      callerIdItem.hidden = enabled;
      callForwardingItem.hidden = cfHidden;
      callBarringItem.hidden = enabled;
      fdnMenuItem.hidden = !hasFdn;
      dtmfItem.hidden = enabled;
      cs_updateDTMFStatus(newType);
      cs_updateVoicePrivacyItemState();
      window.dispatchEvent(new CustomEvent('refresh'));
    }


    function cs_updateDTMFStatus(networkType) {
      let dtmfItem = document.getElementById('menuItem-dtmf');
      if (networkType === 'gsm') {
        dtmfItem.classList.add('none-select');
        dtmfItem.setAttribute('aria-disabled', 'true');
        _settings.createLock().set({'phone.dtmf.type' : 'long'});
      } else {
        dtmfItem.classList.remove('none-select');
        dtmfItem.removeAttribute('aria-disabled');
        _settings.removeObserver('phone.dtmf.type', cs_showToast);
        _settings.addObserver('phone.dtmf.type', cs_showToast);
      }
    }

    function cs_showToast() {
      showToast('changessaved');
    }

    function cs_removeNetworkTypeCheckListener() {
      if (_mobileConnection.voice) {
        _mobileConnection.removeEventListener('voicechange', cs_onTypeChange);
      }
      if (_mobileConnection.data) {
        _mobileConnection.removeEventListener('datachange', cs_onTypeChange);
      }
      if (_imsHandler) {
        _imsHandler.removeEventListener('capabilitychange', cs_onCapabilityChange);
      }
    }

    /**
     *
     */
    function cs_updateVoiceMailItemState() {
      var voiceMailMenuItem = document.getElementById('voiceMail-desc');
      var targetIndex = DsdsSettings.getIccCardIndexForCallSettings();

      voiceMailMenuItem.textContent = '';
      SettingsCache.getSettings(function(results) {
        var numbers = results['ril.iccInfo.mbdn'];
        var number = numbers[targetIndex];
        if (number) {
          voiceMailMenuItem.removeAttribute('data-l10n-id');
          voiceMailMenuItem.textContent = number;
        } else {
          voiceMailMenuItem.setAttribute('data-l10n-id',
                                         'voiceMail-number-notSet');
        }
      });
    }

    function cs_initVoiceMailClickEvent() {
      document.querySelector('.menuItem-voicemail').onclick = function() {
        DialogService.show('call-voiceMailSettings');
      };
    }

    /**
     *
     */
    function cs_initVoiceMailSettings() {
      // update all voice numbers if necessary
      SettingsCache.getSettings(function(results) {
        var settings = navigator.mozSettings;
        var voicemail = navigator.mozVoicemail;
        var updateVMNumber = false;
        var numbers = results['ril.iccInfo.mbdn'] || [];

        Array.prototype.forEach.call(_mobileConnections, function(conn, index) {
          var number = numbers[index];
          // If the voicemail number has not been stored into the database yet
          // we check whether the number is provided by the mozVoicemail API. In
          // that case we store it into the setting database.
          if (!number && voicemail) {
            number = voicemail.getNumber(index);
            if (number) {
              updateVMNumber = true;
              numbers[index] = number;
            }
          }
        });

        if (updateVMNumber) {
          var req = settings.createLock().set({
            'ril.iccInfo.mbdn': numbers
          });
          req.onsuccess = function() {
            cs_updateVoiceMailItemState();
            settings.addObserver('ril.iccInfo.mbdn', function() {
              cs_updateVoiceMailItemState();
            });
          };
        } else {
          cs_updateVoiceMailItemState();
          settings.addObserver('ril.iccInfo.mbdn', function() {
            cs_updateVoiceMailItemState();
          });
        }
      });
    }

    function cs_updateVoicePrivacyItemState() {
      var menuItem = document.getElementById('menuItem-voicePrivacyMode');
      if (!menuItem || menuItem.hidden) {
        return;
      }

      var privacyModeSelect = menuItem.querySelector('select');
      var getReq = _mobileConnection.getVoicePrivacyMode();
      getReq.onsuccess = function get_vpm_success() {
        privacyModeSelect.value = getReq.result;
      };
      getReq.onerror = function get_vpm_error() {
        console.warn('get voice privacy mode: ' + getReq.error.name);
      };
    }

    /**
     * Init voice privacy mode.
     */
    function cs_initVoicePrivacyMode() {
      var defaultVoicePrivacySettings =
      Array.prototype.map.call(_mobileConnections,
        function() { return [true, true]; });
      var voicePrivacyHelper =
        SettingsHelper('ril.voicePrivacy.enabled', defaultVoicePrivacySettings);
      var privacyModeItem =
        document.getElementById('menuItem-voicePrivacyMode');
      var privacyModeSelect =
        privacyModeItem.querySelector('select');

      privacyModeSelect.addEventListener('change',
        function vpm_inputChanged() {
          var checked = (privacyModeSelect.value === 'true' || false);
          voicePrivacyHelper.get(function gotVP(values) {
            var originalValue = !checked;
            var setReq = _mobileConnection.setVoicePrivacyMode(checked);
            setReq.onsuccess = function set_vpm_success() {
              var targetIndex = DsdsSettings.getIccCardIndexForCallSettings();
              values[targetIndex] = !originalValue;
              voicePrivacyHelper.set(values);
            };
            setReq.onerror = function get_vpm_error() {
              // restore the value if failed.
              privacyModeSelect.value = originalValue;
            };
          });
      });
    }

    /**
     *
     */
    function cs_updateFdnStatus() {
      return new Promise((resolve) => {
        let iccObj = getIccByIndex();
        if (!iccObj) {
          return;
        }

        let req = iccObj.getCardLock('fdn');
        req.onsuccess = function spl_checkSuccess() {
          let enabled = req.result.enabled;
          _settings.createLock().set({'ril.fdn.enabled' : enabled});

          let fdnSettingsBlocked =
            document.querySelector('#fdnSettingsBlocked');
          if (fdnSettingsBlocked) {
            fdnSettingsBlocked.hidden = !enabled;
          }
          let callForwardingItem =
            document.getElementById('menuItem-callForwarding');
          let hrefItem = callForwardingItem.querySelector('a');

          if (enabled) {
            callForwardingItem.classList.add('none-select');
            callForwardingItem.setAttribute('aria-disabled', 'true');
            hrefItem.removeAttribute('href');
          } else {
            callForwardingItem.classList.remove('none-select');
            callForwardingItem.removeAttribute('aria-disabled');
            if (DeviceFeature.getValue('vilte') === 'true') {
              hrefItem.setAttribute('href', '#call-cfsettings-list');
            } else {
              hrefItem.setAttribute('href', '#call-cfSettings');
            }
          }
          resolve();
        };
      });
    }

    return {
      init:  function(panel) {
        cs_init();
      },
      onBeforeShow: function() {
        cs_addNetworkTypeCheckListener();
      },
      onBeforeHide: function() {
        cs_removeNetworkTypeCheckListener();
      }
    };
  };
  return CallSettings;
});

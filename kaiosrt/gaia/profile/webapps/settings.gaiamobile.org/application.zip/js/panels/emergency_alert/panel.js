/* global SettingsSoftkey */
/**
 * Used to show Emergency alert panel
 */
define(['require','modules/settings_panel'],function(require) {
  

  var SettingsPanel = require('modules/settings_panel');

  return function ctor_emergency_alert_panel() {
    var elements = {};
    var settingElements = ["cmas.extreme.enabled", "cmas.severe.enabled",
      "cmas.amber.enabled", "cmas.monthlytest.enabled"];
    var listElements = document.querySelectorAll('#emergency-alert li');
    var softkeyParams = {
      menuClassName: 'menu-button',
      header: {
        l10nId: 'message'
      },
      items: [{
        name: 'Deselect',
        l10nId: 'deselect',
        priority: 2,
        method: function() {}
      }]
    };
    var params = {
      menuClassName: 'menu-button',
      header: {
        l10nId: 'message'
      },
      items: [{
        name: 'Select',
        l10nId: 'select',
        priority: 2
      }]
    };

    function _updateSoftkey() {
      var focusedElement = document.querySelector('#emergency-alert .focus');
      if (focusedElement && focusedElement.classList &&
          focusedElement.classList.contains('none-select')) {
        SettingsSoftkey.hide();
        return;
      }
      if (focusedElement && focusedElement.querySelector('input') &&
          focusedElement.querySelector('input').checked) {
        SettingsSoftkey.init(softkeyParams);
      } else {
        SettingsSoftkey.init(params);
      }
      SettingsSoftkey.show();
    }

    function _initAlertSettingListener() {
      var i = settingElements.length - 1;
      for (i; i >= 0; i--) {
        SettingsListener.observe(settingElements[i], true, _updateSoftkey);
      }
    }

    function _removeAlertSettingListener() {
      var i = settingElements.length - 1;
      for (i; i >= 0; i--) {
        SettingsListener.unobserve(settingElements[i] , _updateSoftkey());
      }
    }

    function _keyDownHandler(evt) {
      switch (evt.key) {
        case 'Enter':
          if ('alert-inbox' === evt.target.id) {
            try {
              new MozActivity({
                name: 'alert_inbox'
              });
            } catch (e) {
              console.error('Failed to create an alert_inbox activity: ' + e);
            }
          } else if ('ringtone-preview' === evt.target.id) {
            try {
              new MozActivity({
                name: 'ringtone_preview'
              });
            } catch (e) {
              console.error('Failed to create an alert_inbox activity: ' + e);
            }
          }
          break;
        default:
          break;
      }
    }

    function _updateAlertBodyDisplay(panel) {
      var alertBody = panel.querySelector('#receive-alert-body');
      var request = navigator.mozSettings.createLock().get('cmas.settings.show');
      request.onsuccess = () => {
        var val = request.result['cmas.settings.show'];
        if (val === 'undefined') {
          val = true;
        }
        if (alertBody.hidden === val) {
          alertBody.hidden = !val;
          NavigationMap.refresh();
        }
      };
      request.onerror = () => {
        console.error('ERROR: Can not get the receive alert setting.');
      };
    }

    return SettingsPanel({
      onInit: function(panel) {
        elements = [
          document.getElementById('alert-inbox'),
          document.getElementById('ringtone-preview')
        ];
        _updateAlertBodyDisplay(panel);
      },

      onBeforeShow: function() {
        _updateSoftkey();
        elements.forEach((ele) => {
          ele.addEventListener('keydown', _keyDownHandler);
        });
        ListFocusHelper.addEventListener(listElements, _updateSoftkey);
        _initAlertSettingListener();
      },

      onBeforeHide: function() {
        ListFocusHelper.removeEventListener(listElements, _updateSoftkey);
        _removeAlertSettingListener();
        SettingsSoftkey.hide();
        elements.forEach((ele) => {
          ele.removeEventListener('keydown', _keyDownHandler);
        })
      }
    });
  };
});

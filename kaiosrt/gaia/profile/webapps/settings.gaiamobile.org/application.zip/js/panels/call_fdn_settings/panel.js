define(['require','modules/settings_panel','modules/fdn_dialog','modules/settings_service'],function(require) {
  

  var SettingsPanel = require('modules/settings_panel');
  var FdnDialog = require('modules/fdn_dialog');
  var SettingsService = require('modules/settings_service');

  return function ctor_call_fdn_settings_panel() {
    var _settings = navigator.mozSettings;

    return SettingsPanel({
      onInit: function(panel, options) {
        this._cardIndex = options.cardIndex || 0;
        this._conns = window.navigator.mozMobileConnections;
        this._conn = this._conns[this._cardIndex];

        this._elements = {
          panel: panel,
          resetPin2Item: panel.querySelector('#fdn-resetPIN2'),
          simFdnSelect: document.getElementById('fdn-enabled'),
          resetPin2Button: panel.querySelector('#fdn-resetPIN2 button')
        };

        this._elements.simFdnSelect.addEventListener('change',
          this._showToggleFdnDialog.bind(this));
        this._elements.resetPin2Button.onclick =
          this._showChangePin2Dialog.bind(this);

        this.gaiaHeader = document.querySelector('#simpin2-dialog gaia-header');

        this.params = {
          menuClassName: 'menu-button',
          header: { l10nId:'message' },
          items: [{
            name: 'Select',
            l10nId: 'select',
            priority: 2,
            method: function() {}
          }]
        };
        this.updateFdnState = this._updateFdnState.bind(this);
      },

      onBeforeShow: function(panel, options) {
        this.gaiaHeader.dataset.href = '#call-fdnSettings';
        SettingsSoftkey.init(this.params);
        SettingsSoftkey.show();
        SettingsListener.observe('ril.fdn.enabled', false,
          this.updateFdnState);

        options.cardIndex = DsdsSettings.getIccCardIndexForCallSettings();
        if (typeof options.cardIndex !== 'undefined') {
          this._cardIndex = options.cardIndex;
          this._conn = this._conns[this._cardIndex];
        }

        var iccObj = _getCurrentIccObj(this._cardIndex);
        if (iccObj) {
          iccObj.oncardstatechange = this._updateFdnStatus.bind(this);
        }
      },

      _updateFdnState: function(value) {
        this._elements.simFdnSelect.value = value;
      },

      _showPuk2Dialog: function(action, iccObj) {
        this.gaiaHeader.dataset.href = '#call-fdnSettings';
        FdnDialog.show(action, {
          cardIndex: this._cardIndex,
          onsuccess: () => {
            this._getFdnStatus(iccObj);
          },
          oncancel: () => {
            this._getFdnStatus(iccObj);
          }
        });
      },

      _showToggleFdnDialog: function() {
        var action = this._elements.simFdnSelect.value === 'true' ?
          'enable_fdn' : 'disable_fdn';
        this._updateFdnStatus(action);
      },

      _showChangePin2Dialog: function() {
        this._updateFdnStatus('change_pin2');
      },

      _getFdnStatus: function(iccObj) {
        iccObj.getCardLock('fdn').then((result) => {
          var enabled = result.enabled;
          _settings.createLock().set({'ril.fdn.enabled' : enabled});
          this._elements.simFdnSelect.value = enabled;
        });
      },

      _updateFdnStatus: function(action) {
        var iccObj = _getCurrentIccObj(this._cardIndex);
        if (iccObj) {
          var self = this;
          var req = iccObj.getCardLockRetryCount('pin2');
          req.onsuccess = function() {
            var pin2RetryCount = req.result.retryCount;
            if (!pin2RetryCount) {
              var request = iccObj.getCardLockRetryCount('puk2');
              request.onsuccess = function() {
                var puk2RetryCount = request.result.retryCount;
                if (!puk2RetryCount) {
                  console.log('puk2 locked');
                } else {
                  action = 'unlock_puk2';
                  self._showPuk2Dialog(action, iccObj);
                }
              };
            } else {
              FdnDialog.show(action, {
                cardIndex: self._cardIndex,
                onsuccess: () => {
                  self._getFdnStatus(iccObj);
                },
                oncancel: () => {
                  self._getFdnStatus(iccObj);
                }
              });
            }
          };
        }
      },

      onBeforeHide: function() {
        SettingsSoftkey.hide();
        SettingsListener.unobserve('ril.fdn.enabled', this.updateFdnState);
      }
    });
  };
});

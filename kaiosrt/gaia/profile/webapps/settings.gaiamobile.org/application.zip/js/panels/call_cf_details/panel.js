/* global SettingsSoftkey */
define(['require','modules/settings_service','modules/settings_panel','shared/toaster','shared/settings_listener'],function(require) {
  
  var SettingsService = require('modules/settings_service');
  var SettingsPanel = require('modules/settings_panel');
  var Toaster = require('shared/toaster');
  var SettingsListener = require('shared/settings_listener');

  return function ctor_call_cf_details_panel() {
    var _callForwardingKey,
      _callForwardingNumber;
    var _selectEnable = false;
    var _saveEnable = false;
    var _callForwardingEnabled = false;

    var _inputItem,
      _selectItem;

    var _savedValue = false;

    var settingsKey = {'call-cf-unconditionalSettings' : 'ril.cf.unconditional.enabled',
                       'call-cf-mobileBusySettings' : 'ril.cf.mobilebusy.enabled',
                       'call-cf-noReplySettings' : 'ril.cf.noreply.enabled',
                       'call-cf-notReachableSettings' : 'ril.cf.notreachable.enabled'};

    var numbersKey = {'call-cf-unconditionalSettings' : 'ril.cf.unconditional.number',
                      'call-cf-mobileBusySettings' : 'ril.cf.mobilebusy.number',
                      'call-cf-noReplySettings' : 'ril.cf.noreply.number',
                      'call-cf-notReachableSettings' : 'ril.cf.notreachable.number'};

    function _initSoftkey() {
      var params = {
        menuClassName: 'menu-button',
        header: {
          l10nId: 'message'
        },
        items: []
      };

      if (_selectEnable) {
        params.items.push({
          name: 'Select',
          l10nId: 'select',
          priority: 2,
          method: function() {}
        });
      } else {
        params.items.push({
          name: '',
          l10nId: '',
          priority: 2,
          method: function() {}
        });
      }

      if (_saveEnable) {
        params.items.push({
          name: 'Save',
          l10nId: 'save',
          priority: 3,
          method: function() {
            _setCallForwardingOption();
            SettingsService.navigate('call-cfSettings');
          }
        });
      }
      SettingsSoftkey.init(params);
      SettingsSoftkey.show();
    }

    function _updateUI() {
      var request = SettingsListener.getSettingsLock().get(_callForwardingKey);

      request.onsuccess = function() {
        _savedValue = request.result[_callForwardingKey];
        _callForwardingEnabled = request.result[_callForwardingKey];
        _selectItem.value = _callForwardingEnabled ? 'true' : 'false';
        _updateInputStatus();
      };

      request.onerror = function() {
        var toast = {
          messageL10nId: 'callForwardingSetError',
          latency: 2000,
          useTransition: true
        };
        Toaster.showToast(toast);
        SettingsService.navigate('call-cfSettings');
      };
    }

    function _updateInputStatus() {
      let index = DsdsSettings.getIccCardIndexForCallSettings();
      let enabled = (_selectItem.value === 'true' || false);
      SettingsListener.getSettingsLock().get(_callForwardingNumber)
        .then((result) => {
        let number = result[_callForwardingNumber];
        _inputItem.value = number || '';
        if (enabled) {
          _saveEnable = number ? true : false;
          _inputItem.parentNode.removeAttribute('aria-disabled');
          _inputItem.parentNode.classList.remove('non-focus');
        } else {
          _saveEnable = (_savedValue === enabled) ? false : true;
          _inputItem.parentNode.setAttribute('aria-disabled', 'true');
          _inputItem.parentNode.classList.add('non-focus');
        }
        _selectEnable = true;
        _initSoftkey();
        NavigationMap.refresh();
      })
      .catch((error) => console.log('Promise rejects due to ' + error));
    }

    function _setCallForwardingOption() {
      var enabled = (_selectItem.value === 'true' || false);
      var option = {};
      option[_callForwardingKey] = enabled;
      SettingsListener.getSettingsLock().set(option);
    }

    function _addFocus() {
      _inputItem.focus();
      _updateSaveSoftkey();
    }

    function _updateSelectSoftkey() {
      _selectEnable = true;
      if (_selectItem.value === 'true') {
        _saveEnable = _inputItem.value.length ? true : false;
      } else {
        _saveEnable = false;
      }
      _initSoftkey();
    }

    function _updateSaveSoftkey() {
      _selectEnable = false;
      if (_selectItem.value === 'true' && _inputItem.value.length) {
        _saveEnable = true;
      } else {
        _saveEnable = false;
      }
      _initSoftkey();
    }

    function _updateCursorPos() {
      var cursorPosForInput = _inputItem.value.length;
      _inputItem.setSelectionRange(cursorPosForInput, cursorPosForInput);
    }

    return SettingsPanel({
      onInit: function(panel) {
        _callForwardingKey = settingsKey[panel.id];
        _callForwardingNumber = numbersKey[panel.id];
        _selectItem = panel.querySelector('div select');
        _inputItem = panel.querySelector('li input');
      },

      onBeforeShow: function() {
        _initSoftkey();
        if (!_callForwardingKey) {
          return;
        }
        _updateUI();
        _selectItem.parentNode.parentNode.addEventListener('focus', _updateSelectSoftkey);
        _selectItem.addEventListener('change', _updateInputStatus);
        _inputItem.parentNode.addEventListener('focus', _addFocus);
        _inputItem.addEventListener('input', _updateSaveSoftkey);
        _inputItem.addEventListener('focus', _updateCursorPos);
      },

      onBeforeHide: function() {
        SettingsSoftkey.hide();
        _selectItem.parentNode.parentNode.removeEventListener('focus', _updateSelectSoftkey);
        _selectItem.removeEventListener('change', _updateInputStatus);
        _inputItem.parentNode.removeEventListener('focus', _addFocus);
        _inputItem.removeEventListener('input', _updateSaveSoftkey);
        _inputItem.removeEventListener('focus', _updateCursorPos);
      }
    });
  };
});

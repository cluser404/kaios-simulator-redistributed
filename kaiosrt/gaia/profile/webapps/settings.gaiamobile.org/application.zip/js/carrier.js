/* -*- Mode: js; js-indent-level: 2; indent-tabs-mode: nil -*- */
/* vim: set shiftwidth=2 tabstop=2 autoindent cindent expandtab: */

//
define(['require','shared/settings_listener','shared/toaster','shared/settings_helper','shared/template','shared/simslot_manager','modules/settings_service'],function(require) {
  

  var SettingsListener = require('shared/settings_listener');
  var Toaster = require('shared/toaster');
  var SettingsHelper = require('shared/settings_helper');
  var Template = require('shared/template');
  var SIMSlotManager = require('shared/simslot_manager');
  var SettingsService = require('modules/settings_service');
  /**
   * Singleton object that handles some cell and data settings.
   */
  var CarrierSettings = function cs_carriersettings() {
    var DATA_KEY = 'ril.data.enabled';
    var DATA_ROAMING_KEY = 'ril.data.roaming_enabled';
    var NETWORK_TYPE_SETTING = 'operatorResources.data.icon';
    var networkTypeMapping = {};
    var dataConnectionInit = false;
    var dataRoamingOberverInit = false;
    var dataConnectionSelect = document.querySelector('select.dataConnection-select');
    var dataRoamingDescElement = document.querySelector('small#data-roaming-desc');
    var roamingPreferenceItem = document.getElementById('operator-roaming-preference');
    var operatorHeader = document.querySelector('#carrier-operatorSettings gaia-header h1');

    var _networkTypeCategory = {
      'gprs': 'gsm',
      'edge': 'gsm',
      'umts': 'gsm',
      'hsdpa': 'gsm',
      'hsupa': 'gsm',
      'hspa': 'gsm',
      'hspa+': 'gsm',
      'lte': 'gsm',
      'gsm': 'gsm',
      'is95a': 'cdma',
      'is95b': 'cdma',
      '1xrtt': 'cdma',
      'evdo0': 'cdma',
      'evdoa': 'cdma',
      'evdob': 'cdma',
      'ehrpd': 'cdma'
    };

    var _;
    var _settings;
    var _mobileConnections;
    var _iccManager;
    var _voiceTypes;

    /** mozMobileConnection instance the panel settings rely on */
    var _mobileConnection = null;
    /** Flag */
    var _restartingDataConnection = false;

    var gOperatorNetworkList = null;
    var l10n = window.navigator.mozL10n;
    var currentNetworkType = null;

    /**
     * Init function.
     */
    function cs_init() {
      _settings = window.navigator.mozSettings;
      _mobileConnections = window.navigator.mozMobileConnections;
      _iccManager = window.navigator.mozIccManager;
      if (!_settings || !_mobileConnections || !_iccManager) {
        return;
      }
      window.navigator.mozSettings.addObserver('ril.data.defaultServiceId',
        function (value) {
          for (let i = 0; i < _mobileConnections.length; i++) {
            getSupportedNetworkInfo(_mobileConnections[i], (result) => {
              cs_updateNetworkTypeSelector(result);
              cs_updateAutomaticOperatorSelection();
            });
          };
        }
      );

      // init observer for data connection
      SettingsListener.observe(DATA_KEY, false, function (value) {
        if (dataConnectionInit) {
          var toast = {
            messageL10nId: 'changessaved',
            latency: 2000,
            useTransition: true
          };
          Toaster.showToast(toast);
        } else {
          dataConnectionInit = true;
          dataConnectionSelect.value = value ? true : false;
        }
      });


      // init observer for data roaming
      SettingsListener.observe(DATA_ROAMING_KEY, false, function (value) {
        cs_resetDataRoamingConfiguration(value);
        if (dataRoamingOberverInit) {
          var toast = {
            messageL10nId: 'changessaved',
            latency: 2000,
            useTransition: true
          };
          Toaster.showToast(toast);
        } else {
          dataRoamingOberverInit = true;
        }
      });

      _voiceTypes = Array.prototype.map.call(_mobileConnections,
        function () {
          return null;
        });

      // Get the mozMobileConnection instace for this ICC card.
      _mobileConnection = _mobileConnections[
        DsdsSettings.getIccCardIndexForCellAndDataSettings()];
      if (!_mobileConnection) {
        return;
      }

      cs_addVoiceTypeChangeListeners();
      cs_updateNetworkTypeLimitedItemsVisibility(_mobileConnection);

      // Show carrier name.
      cs_showCarrierName();
      cs_initIccsUI();

      // Init network type selector.
      cs_initNetworkTypeText(cs_initNetworkTypeSelector());
      cs_initOperatorSelector();
      cs_initRoamingPreferenceSelector();

      window.addEventListener('panelready', function (e) {
        var selector = document.getElementById('preferredNetworkType');
        var opAutoSelectOptions = document.getElementById('auto-select-options');
        selector.value = '';
        opAutoSelectOptions.value = '';
        // Get the mozMobileConnection instace for this ICC card.
        _mobileConnection = _mobileConnections[
          DsdsSettings.getIccCardIndexForCellAndDataSettings()];
        if (!_mobileConnection) {
          return;
        }

        var currentHash = e.detail.current;
        if (currentHash === '#carrier') {
          cs_updateNetworkTypeLimitedItemsVisibility(_mobileConnection);
          // Show carrier name.
          cs_showCarrierName();
          cs_updateRoamingPreferenceSelector();
          return;
        }

        if (currentHash === '#apn-settings') {
          if (DsdsSettings.getNumberOfIccSlots() > 1) {
            var apnHeader = document.querySelector('#apn-settings gaia-header h1');
            l10n.setAttributes(
              apnHeader,
              'apnSettingsWithIndex',
              { index: DsdsSettings.getIccCardIndexForCellAndDataSettings() + 1 });
            return;
          } else {
            return;
          }
        }

        if (currentHash === '#carrier-operatorSettings') {
          if (DsdsSettings.getNumberOfIccSlots() > 1) {
            l10n.setAttributes(
              operatorHeader,
              'simSettingsWithIndex',
              { index: DsdsSettings.getIccCardIndexForCellAndDataSettings() + 1 });
          }

          cs_disableAutomaticSelectionState(false);
          cs_updateAutomaticOperatorSelection();
          getSupportedNetworkInfo(_mobileConnection, function (result) {
            cs_updateNetworkTypeSelector(result);
          });
          return;
        }
        return;
      });
    }

    // reset some params related to data roaming after we change its status
    function cs_resetDataRoamingConfiguration(enabled) {
      var iccId = DsdsSettings.getIccCardIndexForCellAndDataSettings();
      _mobileConnection = _mobileConnections[iccId];
      var voiceType = _mobileConnection.voice && _mobileConnection.voice.type;
      if ((_networkTypeCategory[voiceType] === 'cdma') && enabled) {
        roamingPreferenceItem.hidden = false;
      } else {
        roamingPreferenceItem.hidden = true;
      }
      if (enabled) {
        dataRoamingDescElement.setAttribute('data-l10n-id', 'on');
      } else {
        dataRoamingDescElement.setAttribute('data-l10n-id', 'off');
      }
    }

    function cs_initIccsUI() {
      var isMultiSim = DsdsSettings.getNumberOfIccSlots() > 1;
      var carrierInfo = document.querySelector('#carrier .carrier-info');
      var advancedSettings =
        document.querySelector('#carrier .carrier-advancedSettings');
      var simSettings =
        document.querySelector('#carrier .carrier-settings');
      var apnSettings =
        document.querySelector('#carrier .apn-settings');
      var operatorSettingsHeader =
        document.querySelector('#carrier-operatorSettings gaia-header');

      if (isMultiSim) {
        LazyLoader.load([
          '/js/carrier_iccs.js'
        ], function () {
          IccHandlerForCarrierSettings.init();
        });
      }

      operatorSettingsHeader.dataset.href = '#carrier';
      carrierInfo.hidden = isMultiSim;
      advancedSettings.hidden = isMultiSim;
      simSettings.hidden = !isMultiSim;
      apnSettings.hidden = !isMultiSim;
    }

    function cs_initDataToggles() {
      var dataToggle = document.querySelector('#menuItem-enableDataCall input');
      var dataRoamingToggle =
        document.querySelector('#menuItem-enableDataRoaming input');

      function updateDataRoamingToggle(dataEnabled) {
        if (dataEnabled) {
          dataRoamingToggle.disabled = false;
        } else {
          dataRoamingToggle.disabled = true;
          dataRoamingToggle.checked = false;
          dataRoamingToggle.dispatchEvent(new Event('change'));
        }
      }

      function getDataEnabled() {
        return new Promise(function (resolve, reject) {
          var transaction = _settings.createLock();
          var req = transaction.get(DATA_KEY);
          req.onsuccess = function () {
            resolve(req.result[DATA_KEY]);
          };
          req.onerror = function () {
            resolve(false);
          };
        });
      }

      getDataEnabled().then(function (dataEnabled) {
        updateDataRoamingToggle(dataEnabled);
      });
      // We need to disable data roaming when data connection is disabled.
      _settings.addObserver(DATA_KEY, function observerCb(event) {
        dataToggle.checked = event.settingValue;
        if (_restartingDataConnection) {
          return;
        }
        updateDataRoamingToggle(event.settingValue);
      });

      // Init warnings the user sees before enabling data calls and roaming.
      // The function also registers handlers for the changes of the toggles.
      cs_initWarning(DATA_KEY,
        dataToggle,
        'dataConnection-warning-head',
        'dataConnection-warning-message',
        'dataConnection-expl');
      cs_initWarning(DATA_ROAMING_KEY,
        dataRoamingToggle,
        'dataRoaming-warning-head',
        'dataRoaming-warning-message',
        'dataRoaming-expl');
    }

    /**
     * Add listeners on 'voicechange' for show/hide network type limited items.
     */
    function cs_addVoiceTypeChangeListeners() {
      Array.prototype.forEach.call(_mobileConnections, function (conn, index) {
        _voiceTypes[index] = conn.voice.type;
        conn.addEventListener('voicechange', function () {
          var voiceType = conn.voice && conn.voice.type;
          var voiceTypeChange = voiceType !== _voiceTypes[index];

          _voiceTypes[index] = voiceType;
          if (index === DsdsSettings.getIccCardIndexForCellAndDataSettings() &&
            voiceTypeChange) {
            cs_updateNetworkTypeLimitedItemsVisibility(conn);
          }
        });
      });
    }

    /**
     * Update the network type limited items' visibility based on the voice type.
     */
    function cs_updateNetworkTypeLimitedItemsVisibility(conn) {
      // The following features are limited to GSM types.
      var autoSelectOperatorItem = document.getElementById('operator-autoSelect');
      var availableOperatorsHeader =
        document.getElementById('availableOperatorsHeader');
      var availableOperators = document.getElementById('availableOperators');

      var voiceType = conn.voice && conn.voice.type;

      function doUpdate(mode) {
        autoSelectOperatorItem.hidden = availableOperatorsHeader.hidden =
          availableOperators.hidden = (mode !== 'gsm');
      }

      if (!voiceType) {
        getSupportedNetworkInfo(conn, function (result) {
          if (result.gsm || result.wcdma || result.lte) {
            doUpdate('gsm');
          } else {
            doUpdate('cdma');
          }
        });
      } else {
        doUpdate(_networkTypeCategory[voiceType]);
      }
    }

    /**
     * Show the carrier name in the ICC card.
     */
    function cs_showCarrierName() {
      if (DsdsSettings.getNumberOfIccSlots() > 1) {
        return;
      }
      var desc = document.getElementById('dataNetwork-desc');
      var iccCard = _iccManager.getIccById(_mobileConnection.iccId);
      var network = _mobileConnection.voice.network;
      var iccInfo = iccCard.iccInfo;
      var carrier = network ?
        (network.shortName || network.longName || network.mcc + network.mnc) : null;

      if (carrier && iccInfo && iccInfo.isDisplaySpnRequired && iccInfo.spn) {
        if (iccInfo.isDisplayNetworkNameRequired && carrier !== iccInfo.spn) {
          carrier = carrier + ' ' + iccInfo.spn;
        } else {
          carrier = iccInfo.spn;
        }
      }

      if (!carrier) {
        desc.setAttribute('data-l10n-id', 'no-operator');
      } else {
        desc.textContent = carrier;
      }
    }

    /**
     * Helper function. Get the value for the ril.data.defaultServiceId setting
     * from the setting database.
     *
     * @param {Function} callback Callback function to be called once the work is
     *                            done.
     */
    function cs_getDefaultServiceIdForData(callback) {
      var request = _settings.createLock().get('ril.data.defaultServiceId');
      request.onsuccess = function onSuccessHandler() {
        var defaultServiceId =
          parseInt(request.result['ril.data.defaultServiceId'], 10);
        if (callback) {
          callback(defaultServiceId);
        }
      };
    }

    function cs_initNetworkTypeText(aNext) {
      var req;
      try {
        networkTypeMapping = {};
        req = _settings.createLock().get(NETWORK_TYPE_SETTING);
        req.onsuccess = function () {
          var networkTypeValues = req.result[NETWORK_TYPE_SETTING] || {};
          for (var key in networkTypeValues) {
            networkTypeMapping[key] = networkTypeValues[key];
          }
          aNext && aNext();
        };
        req.onerror = function () {
          console.error('Error loading ' + NETWORK_TYPE_SETTING + ' settings. ' +
          req.error && req.error.name);
          aNext && aNext();
        };
      } catch (e) {
        console.error('Error loading ' + NETWORK_TYPE_SETTING + ' settings. ' +
        e);
        aNext && aNext();
      }
    }

    /**
     * Init network type selector. Add the event listener that handles the changes
     * for the network type.
     */
    function cs_initNetworkTypeSelector() {
      if (!_mobileConnection.setPreferredNetworkType)
        return;

      var alertDialog = document.getElementById('preferredNetworkTypeAlert');
      var message = document.getElementById('preferredNetworkTypeAlertMessage');

      var preferredNetworkTypeHelper =
        SettingsHelper('ril.radio.preferredNetworkType');
      var selector = document.getElementById('preferredNetworkType');
      var opAutoSelectOptions = document.getElementById('auto-select-options');
      selector.addEventListener('blur', function evenHandler() {
        var targetIndex = DsdsSettings.getIccCardIndexForCellAndDataSettings();
        var type = selector.value;
        if (currentNetworkType !== type) {
          cs_disableAutomaticSelectionState(true);
          var request = _mobileConnection.setPreferredNetworkType(type);

          request.onsuccess = function onSuccessHandler() {
            preferredNetworkTypeHelper.get(function gotPNT(values) {
              values[targetIndex] = type;
              preferredNetworkTypeHelper.set(values);
              currentNetworkType = type;
              var toast = {
                messageL10nId: 'changessaved',
                useTransition: true
              };
              Toaster.showToast(toast);
              if (opAutoSelectOptions.value === 'true') {
                gOperatorNetworkList.leave();
              } else {
                gOperatorNetworkList.scan();
              }
            });
            cs_disableAutomaticSelectionState(false);
          };
          request.onerror = function onErrorHandler() {
            console.log('setPreferredNetworkType ' + request.error.name);
            if (request.error.name === 'NotAllowedWhenNCK') {
              var checkKey = 'force.nckDialog.show';
              _settings.createLock().get(checkKey).then((result) => {
                var checkValue = result[checkKey];
                if (checkValue) {
                  SettingsService.navigate('simnck', {index: targetIndex});
                } else {
                  var toast = {
                    messageL10nId: 'devicelocked',
                    useTransition: true
                  };
                  Toaster.showToast(toast);
                }
                selector.value = currentNetworkType;
              });
            }
            // XXX, we don't show error dialog now
            cs_disableAutomaticSelectionState(false);
          };
        }
      });

      window.addEventListener('keydown', evt => {
        if (!alertDialog.hidden && evt.key === 'Enter') {
          alertDialog.hidden = true;
          getSupportedNetworkInfo(_mobileConnection, result => {
            cs_updateNetworkTypeSelector(result);
            cs_updateAutomaticOperatorSelection();
          });
        }

        var opAutoSelect = document.getElementById('operator-autoSelect');
        if (evt.key === 'Backspace') {
          var mode = _mobileConnection.networkSelectionMode;
          if (mode === 'automatic') {
            gOperatorNetworkList.leave();
          }
        }

        if (opAutoSelect.classList.contains('focus')) {
          opAutoSelect.style.position = 'static';
        } else {
          opAutoSelect.style.position = 'relative';
        }
      });

      var opAutoSelect = document.getElementById('operator-autoSelect');
      opAutoSelect.addEventListener('focus', evt => {
        opAutoSelect.style.position = 'relative';
      });
    }

    /**
     * Update network type selector.
     */
    function cs_updateNetworkTypeSelector(supportedNetworkTypeResult) {
      if (!_mobileConnection.getPreferredNetworkType || !supportedNetworkTypeResult.networkTypes) {
        return;
      }

      var selector = document.getElementById('preferredNetworkType');
      // Clean up all option before updating again.
      while (selector.hasChildNodes()) {
        selector.removeChild(selector.lastChild);
      }

      var request = _mobileConnection.getPreferredNetworkType();
      request.onsuccess = function onSuccessHandler() {
        currentNetworkType = request.result;
        _addNetworkTypes(request.result);
      };
      request.onerror = function onErrorHandler() {
        console.warn('carrier: could not retrieve network type');
        // XXX, add 'lte' when we can't get preferred network types
        _addNetworkTypes('lte');
      };

      function _addNetworkTypes(networkType) {
        var supportedNetworkTypes = supportedNetworkTypeResult.networkTypes;
        if (networkType) {
          supportedNetworkTypes.forEach(function (type) {
            var option = document.createElement('option');
            option.value = type;
            option.selected = (networkType === type);
            // show user friendly network mode names
            if (type in networkTypeMapping) {
              option.text = networkTypeMapping[type];
            } else {
              var l10nId = supportedNetworkTypeResult.l10nIdForType(type);
              option.setAttribute('data-l10n-id', l10nId);
              // fallback to the network type
              if (!l10nId) {
                option.textContent = type;
              }
            }
            selector.appendChild(option);
          });
        } else {
          console.warn('carrier: could not retrieve network type');
        }
      }
    }

    function cs_disableAutomaticSelectionState(disabled) {
      var networkType = document.getElementById('network-type');
      var opAutoSelectOptions = document.getElementById('auto-select-options');
      var opAutoSelect = document.getElementById('operator-autoSelect');
      var scanItem = document.getElementById('search-again');
      if (disabled) {
        networkType.setAttribute('aria-disabled', 'true');
        opAutoSelectOptions.disabled = true;
        opAutoSelect.setAttribute('aria-disabled', 'true');
        scanItem.disabled = true;
        scanItem.setAttribute('aria-disabled', 'true');
        networkType.classList.add('none-select');
        opAutoSelect.classList.add('none-select');
        scanItem.classList.add('none-select');
        SettingsSoftkey.hide();
      } else {
        networkType.removeAttribute('aria-disabled');
        opAutoSelectOptions.disabled = false;
        opAutoSelect.removeAttribute('aria-disabled');
        scanItem.disabled = false;
        scanItem.removeAttribute('aria-disabled');
        networkType.classList.remove('none-select');
        opAutoSelect.classList.remove('none-select');
        scanItem.classList.remove('none-select');
        SettingsSoftkey.show();
      }
      if (NavigationMap.currentSection === '#carrier-operatorSettings') {
        window.dispatchEvent(new CustomEvent('refresh'));
      }
    }

    /**
     * Network operator selection: auto/manual.
     */
    function cs_initOperatorSelector() {
      var opAutoSelectOptions = document.getElementById('auto-select-options');

      /**
       * Toggle autoselection.
       */
      opAutoSelectOptions.onchange = function () {
        var enabled = (opAutoSelectOptions.value === 'true');
        var targetIndex = DsdsSettings.getIccCardIndexForCellAndDataSettings();
        gOperatorNetworkList.setAutomaticSelection(targetIndex,
            enabled, false);
        cs_disableAutomaticSelectionState(!enabled);
      };

      /**
       * Create a network operator list item.
       */
      function newListItem(network, callback) {
        /**
         * A network list item has the following HTML structure:
         *   <li>
         *     <a>
         *       <span>Network Name</span>
         *     </a>
         *   </li>
         */

        // name
        var name = document.createElement('span');
        name.textContent =
          network.shortName || network.longName || network.mcc + network.mnc;

        var a = document.createElement('a');
        a.appendChild(name);

        // create list item
        var li = document.createElement('li');
        li.appendChild(a);
        li.classList.add('operatorItem');

        // bind connection callback
        li.onclick = function () {
          callback(network, true);
        };
        return li;
      }

      // operator network list
      gOperatorNetworkList = (function operatorNetworkList(list) {
        var networkType = document.getElementById('network-type');
        // get the "Searching..." and "Search Again" items, respectively
        var infoItem = document.getElementById('operators-info');
        var scanItem = list.querySelector('li[data-state="ready"]');
        var connecting = false;
        var operatorItemMap = {};
        var scanRequest = null;
        var opAutoSelectStates = Array.prototype.map.call(_mobileConnections,
          function () {
            return true;
          });

        scanItem.addEventListener('keydown', rescanEventHandler);

        /**
         * "Search Again" button click event handler
         */
        function rescanEventHandler(evt) {
          if (scanItem.disabled) {
            return;
          }
          if (evt.key === 'Enter') {
            scan();
          }
        }

        /**
         * Clear the list.
         */
        function clear() {
          operatorItemMap = {};
          var operatorItems = list.querySelectorAll('li:not([data-state])');
          var len = operatorItems.length;
          for (var i = len - 1; i >= 0; i--) {
            list.removeChild(operatorItems[i]);
          }

          scanItem.classList.remove('focus');
          scanItem.hidden = true;
          if (NavigationMap.currentSection === '#carrier-operatorSettings') {
            window.dispatchEvent(new CustomEvent('refresh'));
          }
        }

        function cs_disableListItems(disabled) {
          var operatorItems =
            Array.prototype.slice.call(list.querySelectorAll('.operatorItem'));
          operatorItems.forEach(function (operatorItem) {
            if (disabled) {
              operatorItem.disabled = true;
              operatorItem.setAttribute('aria-disabled', 'true');
              operatorItem.classList.add('none-select');
            } else {
              operatorItem.disabled = false;
              operatorItem.removeAttribute('aria-disabled');
              operatorItem.classList.remove('none-select');
            }
          });
        }

        /**
         * Select operator.
         */
        function selectOperator(network) {
          if (connecting) {
            return;
          }

          var listItem = operatorItemMap[network.mcc + '.' + network.mnc];
          if (!listItem) {
            return;
          }

          connecting = true;
          cs_disableAutomaticSelectionState(true);
          cs_disableListItems(true);

          var req = _mobileConnection.selectNetwork(network);
          req.onsuccess = function onsuccess() {
            connecting = false;
            checkAutomaticSelection();
            cs_disableAutomaticSelectionState(false);
            cs_disableListItems(false);
          };
          req.onerror = function onerror() {
            connecting = false;
            var dialogConfig = {
              title: { id: 'switch-to-auto-header', args: {} },
              body: { id: 'switch-to-auto', args: {} },
              cancel: {
                name: 'No',
                l10nId: 'no',
                priority: 1,
                callback: function() {
                  console.log('no connected network');
                  cs_disableAutomaticSelectionState(false);
                  cs_disableListItems(false);
                }
              },
              confirm: {
                name: 'Yes',
                l10nId: 'yes',
                priority: 3,
                callback: function() {
                  opAutoSelectOptions.value = 'true';
                  stop();
                  pendingAutomaticSelectionRequest = false;
                  doEnableAutomaticSelection();
                }
              }
            };
            var dialog = new ConfirmDialogHelper(dialogConfig);
            dialog.show(document.getElementById('app-confirmation-dialog'));
          };
        }

        /**
         * Scan available operators.
         */
        function scan() {
          var opAutoSelectOptions =
            document.getElementById('auto-select-options');
          var opAutoSelect = document.getElementById('operator-autoSelect');

          clear();
          list.dataset.state = 'on'; // "Searching..."

          // If we want to show the infoItem content,
          // we should set 'data-state' same as list state.
          infoItem.setAttribute('data-state', 'on');
          infoItem.setAttribute('data-l10n-id', 'scanning');
          cs_disableAutomaticSelectionState(true);

          // invalidate the original request if it exists
          invalidateRequest(scanRequest);
          scanRequest = _mobileConnection.getNetworks();

          scanRequest.onsuccess = function onsuccess() {
            var networks = scanRequest.result;
            for (var i = 0; i < networks.length; i++) {
              var network = networks[i];
              var listItem = newListItem(network, selectOperator);
              list.insertBefore(listItem, scanItem);

              operatorItemMap[network.mcc + '.' + network.mnc] = listItem;
            }
            scanItem.hidden = false;
            list.dataset.state = 'ready'; // "Search Again" button

            scanRequest = null;
            cs_disableAutomaticSelectionState(false);
          };

          scanRequest.onerror = function onScanError(error) {
            if (error.currentTarget.error.name === 'RequestNotSupported') {
              var toast = {
                messageL10nId: 'request-not-supported',
                useTransition: true
              };
              Toaster.showToast(toast);
            }
            console.warn('carrier: could not retrieve any network operator. ');
            scanItem.hidden = false;
            list.dataset.state = 'ready'; // "Search Again" button

            scanRequest = null;
            cs_disableAutomaticSelectionState(false);
          };
        }

        function invalidateRequest(request) {
          if (request) {
            request.onsuccess = request.onerror = function () {
            };
          }
        }

        function leave() {
          list.dataset.state = 'off';
          infoItem.setAttribute('data-state', 'off');
          infoItem.setAttribute('data-l10n-id', 'operator-turnAutoSelectOff');

          operatorItemMap = {};
          var operatorItems = list.querySelectorAll('li:not([data-state])');
          var len = operatorItems.length;
          for (var i = len - 1; i >= 0; i--) {
            list.removeChild(operatorItems[i]);
          }

          scanItem.classList.remove('focus');
          scanItem.hidden = true;
          invalidateRequest(scanRequest);
          scanRequest = null;
        }


        function stop() {
          list.dataset.state = 'off';
          infoItem.setAttribute('data-state', 'off');
          infoItem.setAttribute('data-l10n-id', 'operator-turnAutoSelectOff');
          clear();
          invalidateRequest(scanRequest);
          scanRequest = null;
        }

        var pendingAutomaticSelectionRequest = false;

        function checkAutomaticSelection() {
          if (pendingAutomaticSelectionRequest) {
            doEnableAutomaticSelection();
            pendingAutomaticSelectionRequest = false;
          }
        }

        function doEnableAutomaticSelection() {
          var req = _mobileConnection.selectNetworkAutomatically();
          req.onsuccess = req.onerror = function () {
            opAutoSelectOptions.value = 'true';
            cs_disableAutomaticSelectionState(false);
            cs_disableListItems(false);
          };
        }

        function setAutomaticSelection(index, enabled, skip) {
          opAutoSelectStates[index] = enabled;
          if (enabled) {
            stop();
            // When RIL is actively connecting to an operator, we are not able
            // to set automatic selection. Instead we set a flag indicating that
            // there is a pending automatic selection request.
            if (connecting) {
              pendingAutomaticSelectionRequest = true;
            } else if (!skip) {
              pendingAutomaticSelectionRequest = false;
              doEnableAutomaticSelection();
            }
          } else {
            pendingAutomaticSelectionRequest = false;
            scan();
          }
        }

        function getAutomaticSelection(index) {
          return opAutoSelectStates[index];
        }

        // API
        return {
          leave: leave,
          stop: stop,
          scan: scan,
          setAutomaticSelection: setAutomaticSelection,
          getAutomaticSelection: getAutomaticSelection
        };
      })(document.getElementById('availableOperators'));
    }

    /**
     * Update the automatic operator selection.
     */
    function cs_updateAutomaticOperatorSelection() {
      var opAutoSelectOptions = document.getElementById('auto-select-options');
      var mode = _mobileConnection.networkSelectionMode;
      var newValue = (mode === 'automatic') ? 'true' : 'false';

      opAutoSelectOptions.value = newValue;
      if (opAutoSelectOptions.value === 'true') {
        var targetIndex = DsdsSettings.getIccCardIndexForCellAndDataSettings();
        gOperatorNetworkList.setAutomaticSelection(targetIndex,
          newValue, true);
      } else {
        opAutoSelectOptions.dispatchEvent(new Event('change'));
      }
    }

    /**
     * Update the roaming preference selector.
     */
    function cs_updateRoamingPreferenceSelector() {
      var menuItem = document.getElementById('operator-roaming-preference');
      if (!menuItem || menuItem.hidden) {
        return;
      }

      var selector =
        document.getElementById('operator-roaming-preference-selector');
      var req = _mobileConnection.getRoamingPreference();

      req.onsuccess = function () {
        selector.value = req.result;
      };

      req.onerror = function () {
        console.warn('get roaming preference : ' + req.error.name);
      };
    }

    /**
     * Init roaming preference selector.
     */
    function cs_initRoamingPreferenceSelector() {
      if (!_mobileConnection.getRoamingPreference) {
        document.getElementById('operator-roaming-preference').hidden = true;
        return;
      }

      var defaultRoamingPreferences =
        Array.prototype.map.call(_mobileConnections,
          function () {
            return ['any', 'any'];
          });
      var roamingPreferenceHelper =
        SettingsHelper('ril.roaming.preference', defaultRoamingPreferences);

      var selector =
        document.getElementById('operator-roaming-preference-selector');
      selector.addEventListener('change', (evt) => {
        roamingPreferenceHelper.get(function gotRP(values) {
          var targetIndex =
            DsdsSettings.getIccCardIndexForCellAndDataSettings();
          var setReq = _mobileConnection.setRoamingPreference(selector.value);

          setReq.onsuccess = function set_rp_success() {
            values[targetIndex] = selector.value;
            roamingPreferenceHelper.set(values);

            var toast = {
              messageL10nId: 'changessaved',
              latency: 2000,
              useTransition: true
            };
            Toaster.showToast(toast);
          };

          setReq.onerror = function set_rp_error() {
            selector.value = values[targetIndex];
          };
        });
      });
    }

    /**
     * Init a warning dialog.
     *
     * @param {String} settingKey The key of the setting.
     * @param {String} l10n id of the title.
     * @param {String} l10n id of the message.
     * @param {String} explanationItemId The id of the explanation item.
     */
    function cs_initWarning(settingKey,
                            input,
                            titleL10nId,
                            messageL10nId,
                            explanationItemId) {
      var warningDialogEnabledKey = settingKey + '.warningDialog.enabled';
      var explanationItem = document.getElementById(explanationItemId);

      /**
       * Figure out whether the warning is enabled or not.
       *
       * @param {Function} callback Callback function to be called once the
       *                            work is done.
       */
      function getWarningEnabled(callback) {
        var request = _settings.createLock().get(warningDialogEnabledKey);

        request.onsuccess = function onSuccessHandler() {
          var warningEnabled = request.result[warningDialogEnabledKey];
          if (warningEnabled === null) {
            warningEnabled = true;
          }
          if (callback) {
            callback(warningEnabled);
          }
        };
      }

      /**
       * Set the value of the setting into the settings database.
       *
       * @param {Boolean} state State to be stored.
       */
      function setState(state) {
        var cset = {};
        cset[settingKey] = !!state;
        _settings.createLock().set(cset);
      }

      function getState(callback) {
        var request = _settings.createLock().get(settingKey);
        request.onsuccess = function onSuccessHandler() {
          if (callback) {
            callback(request.result[settingKey]);
          }
        };
      }

      function setWarningDialogState(state) {
        var cset = {};
        cset[warningDialogEnabledKey] = !!state;
        _settings.createLock().set(cset);
      }

      /**
       * Helper function. Handler to be called once the user click on the
       * accept button form the warning dialog.
       */
      function onSubmit() {
        setWarningDialogState(false);
        setState(true);
        explanationItem.hidden = false;
        input.checked = true;
      }

      /**
       * Helper function. Handler to be called once the user click on the
       * cancel button form the warning dialog.
       */
      function onReset() {
        setWarningDialogState(true);
        setState(false);
        input.checked = false;
      }

      // Initialize the state of the input.
      getState(function (enabled) {
        input.checked = enabled;

        // Register an observer to monitor setting changes.
        input.addEventListener('change', function () {
          var enabled = this.checked;
          getWarningEnabled(function getWarningEnabledCb(warningEnabled) {
            if (warningEnabled) {
              if (enabled) {
                require(['modules/dialog_service'], function (DialogService) {
                  DialogService.confirm(messageL10nId, {
                    title: titleL10nId,
                    submitButton: 'turnOn',
                    cancelButton: 'notNow'
                  }).then(function (result) {
                    var type = result.type;
                    if (type === 'submit') {
                      onSubmit();
                    } else {
                      onReset();
                    }
                  });
                });
              }
            } else {
              setState(enabled);
              explanationItem.hidden = false;
            }
          });
        });
      });

      // Initialize the visibility of the warning message.
      getWarningEnabled(function getWarningEnabledCb(warningEnabled) {
        if (warningEnabled) {
          var request = _settings.createLock().get(settingKey);
          request.onsuccess = function onSuccessCb() {
            var enabled = false;
            if (request.result[settingKey] !== undefined) {
              enabled = request.result[settingKey];
            }
            if (enabled) {
              setWarningDialogState(false);
              explanationItem.hidden = false;
            }
          };
        } else {
          explanationItem.hidden = false;
        }
      });
    }

    return {
      init: function (panel) {
        cs_init();
      }
    };
  };
  return CarrierSettings;
});
